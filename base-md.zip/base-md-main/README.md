## CATATAN

Script ini untuk semua orang, bukan untuk Dijual.
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

<h1 align="center">Arifzyn. || Base MD</h1>

---

#### a little about this bot

- [x] **Fast Respon**
- [x] **Simple**
- [x] **Multi Device**
- [x] **Console Log Nice**

---
