const fs = require("fs")
const chalk = require("chalk")

// owner
global.owner = ["6283839357485"]
global.mode = false 
global.ownername = 'BagasDev
global.botname = 'AkemiBot
global.prem = ['6283839357485']
global.group = '' // isi link grupmu
global.ch = '' // isi link ch saluranmu
global.web = '' // isi link websitemu

// payment
global.dana = '6283839357485'
global.gopya = ''
global.ovo = ''
global.saweria = ''

// watermark
global.packname = 'AkemiBot By'
global.author = 'BagasDev'

// global api
global.Key = ''
global.url = ''

// jangan di ubah nanti eror
global.limitawal = {
    premium: "Infinity",
    monayawal: 0,
    free: 100
}

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`Update ${__filename}`));
  delete require.cache[file];
  require(file);
});
